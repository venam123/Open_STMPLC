*PADS-LIBRARY-PART-TYPES-V9*

NVTFS5124PLTAG WDFN8_3.3X3.3_0.65P_CASE_511AB_ISSUE_D_1 I TRX 8 1 0 0 0
TIMESTAMP 2026.03.25.05.12.40
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" NVTFS5124PLTAG
"Mouser Part Number" 863-NVTFS5124PLTAG
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi/NVTFS5124PLTAG?qs=8%252BXDBfnGdBywpAb9wsWb%2FQ%3D%3D
"Arrow Part Number" NVTFS5124PLTAG
"Arrow Price/Stock" https://www.arrow.com/en/products/nvtfs5124pltag/on-semiconductor
"Description" Low On-Resistance; Low Capacitance; AECQ101 Qualified and PPAP Capable; Small Footprint (3.3 x 3.3 mm); NVTFS5124PLWF  Wettable Flanks Product; RoHS Compliant
"Datasheet Link" https://www.onsemi.com/pub/Collateral/NVTFS5124PL-D.PDF
GATE 1 8 0
NVTFS5124PLTAG
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 L G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4

*END*
*REMARK* SamacSys ECAD Model
226959/892109/2.50/8/2/Transistor
